import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks, savgol_filter
from filterpy.kalman import KalmanFilter

# Load the logged data
df = pd.read_csv("D:/3500/Project 3/breathing_log_dual_demo.csv")
time = df["Time(s)"].to_numpy()
voltage_cond = df["Conductive_Voltage(V)"].to_numpy()
voltage_pres = df["Pressure_Voltage(V)"].to_numpy()

# Apply moving average filter (window size = 5)
window_size = 5
ma_voltage_pres = pd.Series(voltage_pres).rolling(window=window_size, center=True).mean().bfill().ffill()
ma_voltage_cond = pd.Series(voltage_cond).rolling(window=window_size, center=True).mean().bfill().ffill()

def apply_Kalman_Filter (voltage_sensor):
    kf = KalmanFilter(dim_x=2, dim_z=1)
    kf.x = np.array([0., 0.])      # Initial state (voltage, velocity)
    kf.F = np.array([[1, 1], [0, 1]])   # State transition
    kf.H = np.array([[1, 0]])           # Measurement function
    kf.P *= 1000.                        # Covariance
    kf.R = 0.01                          # Measurement noise
    kf.Q = 1e-4 * np.eye(2)              # Process noise

    ka_voltage_sensor = []
    for z in voltage_sensor:
        kf.predict()
        kf.update(z)
        ka_voltage_sensor.append(kf.x[0])
    return ka_voltage_sensor

ka_voltage_cond = apply_Kalman_Filter(ma_voltage_cond)
ka_voltage_pres = apply_Kalman_Filter(ma_voltage_pres)

ka_voltage_cond = np.array(ka_voltage_cond)
ka_voltage_pres = np.array(ka_voltage_pres)
# Weighted fusion based on inverse variance
var_cond = np.var(ka_voltage_cond)
var_pres = np.var(ka_voltage_pres)
w_cond = 1 / var_cond
w_pres = 1 / var_pres
fused_signal = (w_cond * ka_voltage_cond + w_pres * ka_voltage_pres) / (w_cond + w_pres)

# Peak detection
fs = 5  # 5 Hz sampling
min_distance = int(fs*5)  # At least 5s apart
peaks, _ = find_peaks(fused_signal, distance=min_distance, prominence=0.002)

# Estimate BPM
duration = time[-1] - time[0]
bpm = len(peaks) * 60 / duration

# Plot
plt.figure(figsize=(10, 4))
plt.plot(time, fused_signal, label="Fused Signal", color='purple')
plt.plot(time[peaks], fused_signal[peaks], 'ro', label="Detected Peaks")
plt.title("Advanced Central-Level Fused Signal with Detected Breaths")
plt.xlabel("Time (s)")
plt.ylabel("Normalized Voltage")
plt.grid(True)
plt.legend()
plt.tight_layout()

info_text = f"Detected Breaths: {len(peaks)} Cycles\nEstimated BPM: {bpm:.1f}"
plt.text(
    0.02, 0.15, info_text,
    transform=plt.gca().transAxes,  # relative to axes
    fontsize=10,
    verticalalignment='top',
    bbox=dict(boxstyle='round,pad=0.4', facecolor='lightyellow', edgecolor='black')
)

plt.show()

print(f"Detected breaths: {len(peaks)}")
print(f"Estimated BPM: {bpm:.1f}")