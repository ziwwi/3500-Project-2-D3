import serial
import csv
import time
import matplotlib.pyplot as plt
import os

ser = serial.Serial("COM14", 115200)  # Update to your STM32 COM port
filename = os.path.expanduser("D:/3500/Project 3/breathing_log_dual_demo_exercise_v2.csv")
timestamps = []
tmp_values = []
pres_values = []
t0 = None  # Base time

with open(filename, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Time(s)", "Conductive_Voltage(V)", "Pressure_Voltage(V)"])

    plt.ion()
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6), sharex=True)

    while plt.fignum_exists(fig.number):
        line = ser.readline().decode().strip()
        try:
            t_raw, tmp_v, pres_v = map(float, line.split(','))
            if t0 is None:
                t0 = t_raw  # First timestamp becomes t=0

            t = t_raw - t0
            timestamps.append(t)
            tmp_values.append(tmp_v)
            pres_values.append(pres_v)
            writer.writerow([t, tmp_v, pres_v])

            # --- Plot Conductive Rubber signal ---
            ax1.clear()
            ax1.plot(timestamps, tmp_values, color='orange')
            ax1.set_ylabel("Voltage (V)")
            ax1.set_title("Conductive Rubber Signal")

            # --- Plot Pressure sensor signal ---
            ax2.clear()
            ax2.plot(timestamps, pres_values, color='blue')
            ax2.set_ylabel("Voltage (V)")
            ax2.set_xlabel("Time (s)")
            ax2.set_title("Pressure Sensor Signal")

            plt.tight_layout()
            plt.pause(0.01)

        except ValueError:
            continue  # Skip malformed lines
